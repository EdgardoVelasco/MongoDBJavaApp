package com.netec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDbJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
