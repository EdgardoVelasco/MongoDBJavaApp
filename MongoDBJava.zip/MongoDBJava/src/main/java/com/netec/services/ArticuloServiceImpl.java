package com.netec.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netec.dao.IArticuloDAO;
import com.netec.entities.Articulo;

@Service
public class ArticuloServiceImpl implements IArticuloService {
	
	@Autowired
	private IArticuloDAO dao;

	@Override
	public List<Articulo> findAll() {
		
		return dao.findAll();
	}

}
