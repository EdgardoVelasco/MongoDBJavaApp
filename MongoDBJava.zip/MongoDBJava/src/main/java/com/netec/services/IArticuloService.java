package com.netec.services;

import java.util.List;

import com.netec.entities.Articulo;

public interface IArticuloService {
	List<Articulo> findAll();
	
}
