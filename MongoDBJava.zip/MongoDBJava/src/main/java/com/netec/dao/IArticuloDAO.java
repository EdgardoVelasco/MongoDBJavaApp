package com.netec.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.netec.entities.Articulo;

public interface IArticuloDAO extends MongoRepository<Articulo, String>{
	

}
